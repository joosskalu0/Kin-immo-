import React, { createContext, useContext, useState, useEffect } from 'react';
import { AlertTriangle, Trash2 } from 'lucide-react';
import {
  Property,
  CustomFieldDefinition,
  Agent,
  Agency,
  SavedSearch,
  LeadRequest,
  User,
  PropertyFilters,
  CurrencyCode,
  LanguageCode,
  Invoice,
  SubscriptionPlan,
  SiteContactSettings,
  PropertyUserReport,
  PropertyVideo,
  PropertyVideoStatus,
  ListingLifecycleStatus,
  AgencyCollaborator,
  AgencyTransaction
} from '../types';
import { analyzePropertyForFraud } from '../utils/suspiciousListingDetector';
import { createStatusHistoryEntry } from '../utils/propertyStatusHelpers';

export interface ConfirmOptions {
  title?: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
}
import {
  initialProperties,
  initialCustomFields,
  initialAgents,
  initialAgencies,
  initialLeads,
  initialInvoices,
  initialSubscriptionPlans,
} from '../data/mockData';
import { translations, languages } from '../utils/i18n';
import { ArchitecturalSlide, INITIAL_ARCHITECTURAL_SLIDES } from '../types/heroShowcase';
import Papa from 'papaparse';
import {
  initGoogleAnalytics,
  trackPropertyView,
  trackContactClick,
  DEFAULT_GA_ID
} from '../utils/analytics';
import {
  getRegisteredAccounts,
  syncFirestoreUsersToAuthStore,
  syncFirestoreAgentsToAuthStore,
} from '../lib/authStore';
import {
  seedInitialFirestoreData,
  subscribeToProperties,
  subscribeToCustomFields,
  subscribeToLeads,
  subscribeToInvoices,
  subscribeToAgents,
  subscribeToAgencies,
  subscribeToUsers,
  savePropertyToFirestore,
  getPropertyFromFirestore,
  deletePropertyFromFirestore,
  saveCustomFieldToFirestore,
  deleteCustomFieldFromFirestore,
  saveLeadToFirestore,
  deleteLeadFromFirestore,
  saveUserToFirestore,
  deleteUserFromFirestore,
  saveInvoiceToFirestore,
  deleteInvoiceFromFirestore,
  saveAgentToFirestore,
  deleteAgentFromFirestore,
  saveAgencyToFirestore,
  deleteAgencyFromFirestore,
  subscribeToPricingConfig,
  savePricingConfigToFirestore,
  listenToAuthChanges,
  logOutFromFirebase
} from '../lib/kinimmoStore';
import { mysqlApi } from '../services/mysqlApi';
import { getAdminCredentials, saveAdminCredentials } from '../lib/adminCredentials';
import { parsePropertyIdFromUrl, updateBrowserUrlForProperty } from '../utils/shareUtils';

interface AppContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  currency: CurrencyCode;
  setCurrency: (curr: CurrencyCode) => void;
  t: (key: string) => string;

  user: User | null;
  setUser: (user: User | null) => void;
  deleteUser: (id: string) => void;
  allUsers: User[];
  logOut: () => Promise<void>;

  // Invitation link support for agents & agencies
  invitedRole: 'agent' | 'agency' | null;
  invitedBy: string | null;
  clearInvite: () => void;
  isInviteModalOpen: boolean;
  setIsInviteModalOpen: (open: boolean) => void;

  customFields: CustomFieldDefinition[];
  addCustomField: (field: CustomFieldDefinition) => void;
  updateCustomField: (field: CustomFieldDefinition) => void;
  deleteCustomField: (id: string) => void;

  properties: Property[];
  addProperty: (property: Property) => Promise<void> | void;
  updateProperty: (property: Property) => Promise<void> | void;
  deleteProperty: (id: string) => void;
  updatePropertyListingStatus: (propertyId: string, status: ListingLifecycleStatus, note?: string) => Promise<{ success: boolean; message?: string }>;
  assignPropertyToAgent: (propertyId: string, assignedAgentId: string, assignedAgentName: string) => Promise<void>;

  // Agency Collaborators & Transactions
  agencyCollaborators: AgencyCollaborator[];
  inviteAgencyCollaborator: (data: any) => Promise<{ success: boolean; message?: string; collaborator?: AgencyCollaborator }>;
  updateAgencyCollaborator: (id: string, data: Partial<AgencyCollaborator>) => Promise<void>;
  deleteAgencyCollaborator: (id: string) => Promise<void>;
  agencyTransactions: AgencyTransaction[];
  createAgencyTransaction: (data: any) => Promise<{ success: boolean; transaction?: AgencyTransaction }>;

  agents: Agent[];
  addAgent: (agent: Agent) => void;
  updateAgent: (agent: Agent) => void;
  deleteAgent: (id: string) => void;
  toggleAgentVisibility: (agentId: string) => void;
  updateAgentVerification: (
    agentId: string,
    isVerified: boolean,
    verificationStatus: 'unverified' | 'pending' | 'verified' | 'rejected',
    rejectionReason?: string,
    verifiedBy?: string
  ) => void;
  updateAgentVerificationDocument: (
    agentId: string,
    docId: string,
    status: 'approved' | 'rejected',
    rejectionNote?: string
  ) => void;
  submitAgentVerificationDocuments: (
    agentId: string,
    documents: import('../types').VerificationDocument[],
    identityDocType?: any,
    identityDocNumber?: string,
    rccmOrNif?: string
  ) => void;

  agencies: Agency[];
  addAgency: (agency: Agency) => void;
  updateAgency: (agency: Agency) => void;
  deleteAgency: (id: string) => void;
  toggleAgencyVisibility: (agencyId: string) => void;
  updateAgencySubscriptionStatus: (agencyId: string, status: 'Active' | 'Expired', expiresAt?: string) => void;
  updateUserSubscriptionStatus: (targetIdOrEmail: string, status: 'Active' | 'Expired', expiresAt?: string) => void;

  // Subscription Plans & Pricing in Francs Congolais (CDF)
  subscriptionPlans: SubscriptionPlan[];
  updateSubscriptionPlan: (plan: SubscriptionPlan) => void;
  addSubscriptionPlan: (plan: SubscriptionPlan) => void;
  deleteSubscriptionPlan: (id: string) => void;
  pricingDisplayCurrency: 'CDF' | 'USD' | 'BOTH';
  setPricingDisplayCurrency: (mode: 'CDF' | 'USD' | 'BOTH') => void;
  cdfExchangeRate: number;
  setCdfExchangeRate: (rate: number) => void;

  wishlist: string[];
  toggleWishlist: (propertyId: string) => void;

  compareList: string[];
  toggleCompare: (propertyId: string) => void;
  clearCompare: () => void;

  savedSearches: SavedSearch[];
  addSavedSearch: (title: string, notifyFrequency: SavedSearch['notifyFrequency']) => void;
  deleteSavedSearch: (id: string) => void;

  leads: LeadRequest[];
  addLeadRequest: (lead: Omit<LeadRequest, 'id' | 'createdAt' | 'status'>) => void;
  updateLeadStatus: (leadId: string, status: LeadRequest['status']) => void;
  deleteLead: (id: string) => void;

  invoices: Invoice[];
  addInvoice: (invoice: Invoice) => void;
  updateInvoice: (invoice: Invoice) => void;
  updateInvoiceStatus: (id: string, status: Invoice['status'], paymentMethod?: Invoice['paymentMethod'], notes?: string) => void;
  deleteInvoice: (id: string) => void;

  adminPin: string;
  updateAdminPin: (newPin: string) => Promise<void>;

  filters: PropertyFilters;
  setFilters: React.Dispatch<React.SetStateAction<PropertyFilters>>;
  resetFilters: () => void;

  // Modals & Active State
  activePropertyModalId: string | null;
  setActivePropertyModalId: (id: string | null) => void;
  isFieldsBuilderOpen: boolean;
  setIsFieldsBuilderOpen: (open: boolean) => void;
  isSubmitPropertyOpen: boolean;
  setIsSubmitPropertyOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isSecurityModalOpen: boolean;
  setIsSecurityModalOpen: (open: boolean) => void;
  isCompareOpen: boolean;
  setIsCompareOpen: (open: boolean) => void;
  editingProperty: Property | null;
  setEditingProperty: (prop: Property | null) => void;

  importCSV: (csvContent: string) => void;
  exportCSV: () => void;

  // Google Analytics & Listing Views Tracking
  googleAnalyticsId: string;
  updateGoogleAnalyticsId: (newId: string) => void;
  incrementPropertyViews: (propertyId: string) => void;
  recordPropertyAction: (propertyId: string, action: 'whatsapp' | 'call' | 'lead' | 'share') => void;

  requestConfirm: (options: ConfirmOptions) => void;

  // Vitrine d'Exception & Mises en Avant (Hero Showcase Safricode Style)
  heroSlides: ArchitecturalSlide[];
  setHeroSlides: React.Dispatch<React.SetStateAction<ArchitecturalSlide[]>>;
  addHeroSlide: (slide: ArchitecturalSlide) => void;
  updateHeroSlide: (id: string, slide: Partial<ArchitecturalSlide>) => void;
  deleteHeroSlide: (id: string) => void;
  promotePropertyToHero: (propertyId: string) => void;
  removePropertyFromHero: (propertyId: string) => void;

  // Coordonnées de Contact & Conciergerie VIP
  contactSettings: SiteContactSettings;
  updateContactSettings: (newSettings: Partial<SiteContactSettings>) => Promise<{ success: boolean; message?: string }>;

  // Signalements & Détection Anti-Fraude
  reports: PropertyUserReport[];
  addPropertyReport: (report: Omit<PropertyUserReport, 'id' | 'createdAt' | 'status'>) => Promise<void> | void;
  resolvePropertyReport: (reportId: string, action: 'resolved' | 'dismissed') => void;

  // Kinimmo Visites (Vidéos Verticales Immersives & Modération)
  propertyVideos: PropertyVideo[];
  loadPropertyVideos: () => Promise<void>;
  addPropertyVideo: (videoData: {
    propertyId: string;
    videoUrl: string;
    thumbnailUrl?: string;
    description?: string;
    status?: PropertyVideoStatus;
  }) => Promise<{ success: boolean; message?: string }>;
  updatePropertyVideoStatus: (id: string, status: PropertyVideoStatus, reason?: string) => Promise<void>;
  deletePropertyVideo: (id: string) => Promise<void>;
}

const defaultFilters: PropertyFilters = {
  searchQuery: '',
  city: '',
  type: 'all',
  status: 'all',
  category: '',
  minPrice: 0,
  maxPrice: 5000000,
  minBedrooms: 0,
  minBathrooms: 0,
  minArea: 0,
  maxArea: 2000,
  labels: [],
  amenities: [],
  customFields: {},
  sortBy: 'newest',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

const DURABLE_PROPERTIES_KEY = 'immocraft_durable_published_properties';
const DELETED_PROPERTIES_KEY = 'immocraft_deleted_properties_registry';

const getDurableLocalProperties = (): Property[] => {
  try {
    const raw = localStorage.getItem(DURABLE_PROPERTIES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return [];
};

const saveDurableLocalProperties = (list: Property[]) => {
  try {
    localStorage.setItem(DURABLE_PROPERTIES_KEY, JSON.stringify(list));
  } catch {}
};

const getDeletedPropertiesIds = (): Set<string> => {
  try {
    const raw = localStorage.getItem(DELETED_PROPERTIES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return new Set(parsed);
    }
  } catch {}
  return new Set();
};

const markPropertyAsDeletedLocally = (id: string) => {
  try {
    const deleted = getDeletedPropertiesIds();
    deleted.add(id);
    localStorage.setItem(DELETED_PROPERTIES_KEY, JSON.stringify(Array.from(deleted)));
  } catch {}
};

const HERO_SLIDES_KEY = 'kinimmo_hero_showcase_slides';

const getInitialHeroSlides = (): ArchitecturalSlide[] => {
  try {
    const raw = localStorage.getItem(HERO_SLIDES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ne conserver que les slides réellement rattachés à un bien immobilier
        const valid = parsed.filter((slide) => slide && slide.propertyId);
        return valid;
      }
    }
  } catch {}
  return [];
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<LanguageCode>('fr');
  const [currency, setCurrency] = useState<CurrencyCode>('USD');
  const [user, setUser] = useState<User | null>(() => {
    try {
      if (typeof window !== 'undefined') {
        const raw = localStorage.getItem('kinimmo_user');
        return raw ? JSON.parse(raw) : null;
      }
      return null;
    } catch {
      return null;
    }
  });

  // Invitation link state for agents & agencies
  const [invitedRole, setInvitedRole] = useState<'agent' | 'agency' | null>(null);
  const [invitedBy, setInvitedBy] = useState<string | null>(null);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);

  // Proactively clean up legacy temporary items from old migrations (without touching kinimmo data)
  useEffect(() => {
    try {
      localStorage.removeItem('estatik_kinshasa_user');
      localStorage.removeItem('estatik_admin_credentials_v1');
      localStorage.removeItem('immocraft_agents');
      localStorage.removeItem('immocraft_agencies');
      localStorage.removeItem('estatik_registered_users');
      localStorage.removeItem('estatik_local_registered_accounts');
      localStorage.removeItem('immocraft_custom_fields');
      localStorage.removeItem('immocraft_saved_searches');
      localStorage.removeItem('kin_tracking_config');
      localStorage.removeItem('immocraft_durable_published_properties');
      localStorage.removeItem('estatik_durable_properties');
      localStorage.removeItem('immocraft_property_user_reports');
    } catch {}
  }, []);

  // Écouter les changements d'état d'authentification utilisateur
  useEffect(() => {
    const unsub = listenToAuthChanges((currentUser) => {
      setUser(currentUser);
    });
    return () => unsub();
  }, []);

  // Check URL query parameters for agent/agency invitation links
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const params = new URLSearchParams(window.location.search);
        const inviteParam = params.get('invite');
        const refParam = params.get('ref') || params.get('agency');
        if (inviteParam === 'agent' || inviteParam === 'agency') {
          setInvitedRole(inviteParam);
          setInvitedBy(refParam || null);
          setIsAuthModalOpen(true);
        }
      } catch (e) {
        console.warn('Error reading invite search params:', e);
      }
    }
  }, []);

  const clearInvite = () => {
    setInvitedRole(null);
    setInvitedBy(null);
  };

  const logOut = async () => {
    setUser(null);
    await logOutFromFirebase();
  };

  // Session expirée : l'API a répondu 401 (jeton invalide ou périmé). On déconnecte proprement
  // l'utilisateur au lieu de le laisser "connecté" alors que toutes ses actions échouent.
  useEffect(() => {
    const handleSessionExpired = () => {
      setUser(null);
      try { localStorage.removeItem('kinimmo_user'); } catch {}
      logOutFromFirebase().catch(() => {});
      setIsAuthModalOpen(true);
    };
    window.addEventListener('kinimmo-session-expired', handleSessionExpired);
    return () => window.removeEventListener('kinimmo-session-expired', handleSessionExpired);
  }, []);

  // Magasin de données Kinimmo - synchronisé avec l'API MySQL et le stockage local
  const [customFields, setCustomFields] = useState<CustomFieldDefinition[]>(initialCustomFields);
  const [properties, setProperties] = useState<Property[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [agencies, setAgencies] = useState<Agency[]>([]);

  const [subscriptionPlans, setSubscriptionPlans] = useState<SubscriptionPlan[]>(initialSubscriptionPlans);

  const [pricingDisplayCurrency, setPricingDisplayCurrency] = useState<'CDF' | 'USD' | 'BOTH'>('CDF');
  const [cdfExchangeRate, setCdfExchangeRate] = useState<number>(2800);

  const [wishlist, setWishlist] = useState<string[]>([]);
  const [compareList, setCompareList] = useState<string[]>([]);
  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>([]);

  const [leads, setLeads] = useState<LeadRequest[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);

  // Signalements utilisateurs & Anti-Fraude
  const REPORTS_STORAGE_KEY = 'immocraft_property_user_reports';
  const [reports, setReports] = useState<PropertyUserReport[]>(() => {
    try {
      const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  });

  const saveReportsLocally = (newList: PropertyUserReport[]) => {
    try {
      localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(newList));
    } catch {}
  };

  const addPropertyReport = async (reportData: Omit<PropertyUserReport, 'id' | 'createdAt' | 'status'>) => {
    const newReport: PropertyUserReport = {
      ...reportData,
      id: `rep_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      status: 'pending'
    };

    setReports((prev) => {
      const updated = [newReport, ...prev];
      saveReportsLocally(updated);
      return updated;
    });

    // Mettre à jour l'annonce concernée pour ré-exécuter l'analyse anti-fraude
    setProperties((prev) => {
      const target = prev.find((p) => p.id === reportData.propertyId);
      if (!target) return prev;

      const currentReports = [...reports, newReport];
      const analysis = analyzePropertyForFraud(target, prev, currentReports);

      const updatedProp: Property = {
        ...target,
        fraudStatus: analysis.verdict,
        fraudScore: analysis.riskScore,
        fraudFlags: analysis.flags,
        fraudLastCheckedAt: analysis.analyzedAt,
        userReportsCount: (target.userReportsCount || 0) + 1,
        // Si le verdict bascule à suspect, blocage temporaire immédiat !
        published: analysis.verdict === 'normal' ? target.published : false
      };

      const updatedList = prev.map((p) => (p.id === updatedProp.id ? updatedProp : p));
      saveDurableLocalProperties(updatedList);
      return updatedList;
    });
  };

  const resolvePropertyReport = (reportId: string, action: 'resolved' | 'dismissed') => {
    setReports((prev) => {
      const updated = prev.map((r) => (r.id === reportId ? { ...r, status: action } : r));
      saveReportsLocally(updated);
      return updated;
    });
  };

  // -----------------------------------------------------------
  // KINIMMO VISITES (Vidéos Verticales Immersives & Modération)
  // -----------------------------------------------------------
  const VIDEOS_STORAGE_KEY = 'kinimmo_property_videos_v1';
  const [propertyVideos, setPropertyVideos] = useState<PropertyVideo[]>(() => {
    try {
      const saved = localStorage.getItem(VIDEOS_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    return [];
  });

  const saveVideosLocally = (videos: PropertyVideo[]) => {
    try {
      localStorage.setItem(VIDEOS_STORAGE_KEY, JSON.stringify(videos));
    } catch {}
  };

  const loadPropertyVideos = async () => {
    try {
      const res = await mysqlApi.getApprovedVideos();
      if (res.success && res.data?.videos && res.data.videos.length > 0) {
        setPropertyVideos(res.data.videos);
        saveVideosLocally(res.data.videos);
      }
    } catch (e) {
      console.warn('Could not load videos from MySQL API, using local videos:', e);
    }
  };

  const addPropertyVideo = async (videoData: {
    propertyId: string;
    videoUrl: string;
    thumbnailUrl?: string;
    description?: string;
    status?: PropertyVideoStatus;
  }): Promise<{ success: boolean; message?: string }> => {
    const linkedProp = properties.find((p) => p.id === videoData.propertyId);
    if (!linkedProp) {
      throw new Error('Annonce immobilière introuvable pour cette vidéo.');
    }

    const newVideo: PropertyVideo = {
      id: `vid_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      propertyId: videoData.propertyId,
      userId: user?.id || 'agent_current',
      videoUrl: videoData.videoUrl,
      thumbnailUrl: videoData.thumbnailUrl || linkedProp.images?.[0],
      description: videoData.description || '',
      status: videoData.status || 'pending',
      viewsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      propertyTitle: linkedProp.title,
      propertyPrice: linkedProp.price,
      propertyCurrency: linkedProp.currency,
      propertyCommune: linkedProp.commune,
      propertyQuartier: linkedProp.quartier,
      propertyType: linkedProp.type,
      propertyStatus: linkedProp.status,
      propertyBedrooms: linkedProp.bedrooms,
      propertyBathrooms: linkedProp.bathrooms,
      propertyAddress: linkedProp.address,
      propertyFeatured: linkedProp.featured,
      agentName: user?.name || linkedProp.agencyName || 'Conseiller Kinimmo',
      agencyName: linkedProp.agencyName,
      agentPhone: linkedProp.contactPhone || user?.phone,
      agentWhatsapp: linkedProp.contactPhone || user?.phone,
      agentAvatar: user?.avatar,
      agentVerified: user?.isVerified || false
    };

    // Tenter la persistance via l'API MySQL
    try {
      await mysqlApi.createVideo(videoData);
    } catch (e) {
      console.warn('MySQL API createVideo fallback to local storage:', e);
    }

    setPropertyVideos((prev) => {
      const updated = [newVideo, ...prev];
      saveVideosLocally(updated);
      return updated;
    });

    return {
      success: true,
      message: newVideo.status === 'draft'
        ? 'Brouillon de vidéo enregistré avec succès.'
        : 'Vidéo soumise à validation administrative avec succès.'
    };
  };

  const updatePropertyVideoStatus = async (id: string, status: PropertyVideoStatus, reason?: string) => {
    try {
      await mysqlApi.adminModerateVideo(id, status, reason);
    } catch (e) {
      console.warn('MySQL API adminModerateVideo fallback to local state:', e);
    }

    setPropertyVideos((prev) => {
      const updated = prev.map((v) =>
        v.id === id ? { ...v, status, rejectionReason: reason, updatedAt: new Date().toISOString() } : v
      );
      saveVideosLocally(updated);
      return updated;
    });
  };

  const deletePropertyVideo = async (id: string) => {
    try {
      await mysqlApi.deleteVideo(id);
    } catch (e) {
      console.warn('MySQL API deleteVideo fallback to local state:', e);
    }

    setPropertyVideos((prev) => {
      const updated = prev.filter((v) => v.id !== id);
      saveVideosLocally(updated);
      return updated;
    });
  };
  const [filters, setFilters] = useState<PropertyFilters>(defaultFilters);

  // Modals & Deep Linking
  const [activePropertyModalId, setActivePropertyModalId] = useState<string | null>(() => {
    return parsePropertyIdFromUrl();
  });
  const [isFieldsBuilderOpen, setIsFieldsBuilderOpen] = useState(false);
  const [isSubmitPropertyOpen, setIsSubmitPropertyOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);

  // Vitrine d'Exception & Mises en Avant (Hero Showcase)
  const [heroSlides, setHeroSlides] = useState<ArchitecturalSlide[]>(getInitialHeroSlides);

  // Sync slides with MySQL if available
  useEffect(() => {
    let isMounted = true;
    mysqlApi.getHeroSlides().then((remoteSlides) => {
      if (isMounted && remoteSlides && Array.isArray(remoteSlides) && remoteSlides.length > 0) {
        setHeroSlides(remoteSlides);
      }
    }).catch(() => {});

    // Charger les vidéos approuvées depuis l'API backend
    loadPropertyVideos().catch(() => {});

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(HERO_SLIDES_KEY, JSON.stringify(heroSlides));
    } catch {}
  }, [heroSlides]);

  const addHeroSlide = (slide: ArchitecturalSlide) => {
    setHeroSlides((prev) => [slide, ...prev]);
    mysqlApi.adminCreateHeroSlide(slide).catch(() => {});
  };

  const updateHeroSlide = (id: string, updated: Partial<ArchitecturalSlide>) => {
    setHeroSlides((prev) => prev.map((s) => (s.id === id ? { ...s, ...updated } : s)));
    mysqlApi.adminUpdateHeroSlide(id, updated).catch(() => {});
  };

  const deleteHeroSlide = (id: string) => {
    setHeroSlides((prev) => prev.filter((s) => s.id !== id));
    mysqlApi.adminDeleteHeroSlide(id).catch(() => {});
  };

  const promotePropertyToHero = (propertyId: string) => {
    const prop = properties.find((p) => p.id === propertyId);
    if (!prop) return;

    // Résoudre l'agence ou l'agent référent assigné à ce bien
    const assignedAgent = prop.agentId ? agents.find((a) => a.id === prop.agentId) : null;
    const assignedAgency = prop.agencyId
      ? agencies.find((a) => a.id === prop.agencyId || a.name === prop.agencyName)
      : (assignedAgent?.agencyId ? agencies.find((a) => a.id === assignedAgent.agencyId) : null);

    const hasAdminNumber = (num?: string) => Boolean(num && num.replace(/[^0-9]/g, '').includes('845294616'));

    const directWhatsapp =
      (assignedAgency?.whatsapp && !hasAdminNumber(assignedAgency.whatsapp) ? assignedAgency.whatsapp : null) ||
      (assignedAgent?.whatsapp && !hasAdminNumber(assignedAgent.whatsapp) ? assignedAgent.whatsapp : null) ||
      (prop.contactPhone && !hasAdminNumber(prop.contactPhone) ? prop.contactPhone : null) ||
      assignedAgency?.phone ||
      assignedAgent?.phone ||
      '+243 81 000 0001';

    const directPhone =
      (assignedAgency?.phone && !hasAdminNumber(assignedAgency.phone) ? assignedAgency.phone : null) ||
      (assignedAgent?.phone && !hasAdminNumber(assignedAgent.phone) ? assignedAgent.phone : null) ||
      directWhatsapp;

    const directName = assignedAgency?.name || (assignedAgent ? `${assignedAgent.name}` : (prop.agencyName || 'Service Commercial'));
    const directRole = assignedAgency ? assignedAgency.name : (assignedAgent ? `Conseiller Immobilier (${assignedAgent.name})` : 'Service Commercial');
    const directEmail = assignedAgency?.email || assignedAgent?.email || 'contact@kinimmo.com';
    const directLegalStatus = prop.customFields?.titre_foncier || 'Certificat d’Enregistrement Notarié & Titre Foncier Conforme';

    const newSlide: ArchitecturalSlide = {
      id: `slide_prop_${prop.id}`,
      badgeCategory: prop.category?.toUpperCase() || (prop.status === 'for-sale' ? 'VENTE DE STANDING' : 'LOCATION DE LUXE'),
      badgeLocation: `${(prop.commune || prop.city || 'KINSHASA').toUpperCase()}`,
      title: prop.title.toUpperCase(),
      subTitle: `${(prop.type || 'Résidence').toUpperCase()} D'EXCEPTION • KINSHASA`,
      description: prop.description || 'Superbe opportunité immobilière de grand standing à Kinshasa avec titre foncier garanti.',
      image: prop.images?.[0] || 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1600&auto=format&fit=crop&q=85',
      propertyType: prop.type,
      commune: prop.commune || 'Gombe',
      propertyId: prop.id,
      isActive: true,
      order: 1,
      contactName: directName,
      contactRole: directRole,
      contactPhone: directPhone,
      contactWhatsapp: directWhatsapp,
      contactEmail: directEmail,
      legalStatus: directLegalStatus,
      stats: {
        units: prop.bedrooms ? `${prop.bedrooms} Chambres` : 'Standing',
        parking: prop.bathrooms ? `${prop.bathrooms} Salles d'eau` : 'Parking Sécurisé',
        surface: prop.area ? `${prop.area} m²` : '320 m²'
      },
      details: {
        amenities: prop.amenities && prop.amenities.length > 0 ? prop.amenities.slice(0, 5) : [
          'Sécurité 24/7 & Gardiennage VIP',
          'Alimentation électrique continue (Groupe & Solaire)',
          'Titre foncier et certificat vérifié au Cadastre'
        ],
        priceInfo: `$${prop.price?.toLocaleString()} ${prop.period === 'month' ? '/ mois' : ''}`,
        deliveryDate: 'Disponible immédiatement'
      }
    };

    setHeroSlides((prev) => [newSlide, ...prev.filter((s) => s.propertyId !== propertyId)]);

    setProperties((prev) =>
      prev.map((p) => {
        if (p.id === propertyId) {
          const currentLabels = p.labels || [];
          if (!currentLabels.includes('featured')) {
            return { ...p, labels: [...currentLabels, 'featured'] };
          }
        }
        return p;
      })
    );
  };

  const removePropertyFromHero = (propertyId: string) => {
    setHeroSlides((prev) => prev.filter((s) => s.propertyId !== propertyId));
  };

  // Coordonnées de Contact & Conciergerie VIP
  const [contactSettings, setContactSettings] = useState<SiteContactSettings>(() => {
    return mysqlApi.getStoredContactSettings();
  });

  useEffect(() => {
    let isMounted = true;
    mysqlApi.getContactSettings().then((remoteSettings) => {
      if (isMounted && remoteSettings) {
        setContactSettings(remoteSettings);
      }
    }).catch(() => {});
    return () => {
      isMounted = false;
    };
  }, []);

  const updateContactSettings = async (newSettings: Partial<SiteContactSettings>) => {
    const merged: SiteContactSettings = {
      ...contactSettings,
      ...newSettings,
      vipConcierge: {
        ...contactSettings.vipConcierge,
        ...(newSettings.vipConcierge || {})
      }
    };
    setContactSettings(merged);
    return await mysqlApi.adminUpdateContactSettings(merged);
  };

  // Deep-linking URL Synchronization & Browser History Navigation
  useEffect(() => {
    const handlePopState = () => {
      const propId = parsePropertyIdFromUrl();
      setActivePropertyModalId(propId);
      if (propId) {
        incrementPropertyViews(propId);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  // Synchronisation de l'URL et récupération de la propriété si nécessaire
  useEffect(() => {
    if (!activePropertyModalId) {
      updateBrowserUrlForProperty(null);
      return;
    }

    const foundProp = properties.find((p) => p.id === activePropertyModalId);
    if (foundProp) {
      updateBrowserUrlForProperty(foundProp.id, foundProp.title);
    } else {
      // Récupérer depuis le magasin de données
      let isMounted = true;
      getPropertyFromFirestore(activePropertyModalId).then((fetchedProp) => {
        if (isMounted && fetchedProp) {
          setProperties((prev) => {
            if (prev.some((p) => p.id === fetchedProp.id)) return prev;
            return [fetchedProp, ...prev];
          });
          updateBrowserUrlForProperty(fetchedProp.id, fetchedProp.title);
        }
      });
      return () => {
        isMounted = false;
      };
    }
  }, [activePropertyModalId, properties]);

  // Confirm Modal State
  const [confirmState, setConfirmState] = useState<ConfirmOptions | null>(null);

  const requestConfirm = (options: ConfirmOptions) => {
    setConfirmState(options);
  };

  // Google Analytics ID State
  const [googleAnalyticsId, setGoogleAnalyticsIdState] = useState<string>(DEFAULT_GA_ID);

  useEffect(() => {
    initGoogleAnalytics(googleAnalyticsId);
  }, [googleAnalyticsId]);

  const updateGoogleAnalyticsId = (newId: string) => {
    const cleanId = newId.trim() || DEFAULT_GA_ID;
    setGoogleAnalyticsIdState(cleanId);
    initGoogleAnalytics(cleanId);
  };

  const [adminPin, setAdminPinState] = useState<string>(() => {
    const creds = getAdminCredentials();
    return creds.pin || '';
  });

  const updateAdminPin = async (newPin: string) => {
    setAdminPinState(newPin);
    saveAdminCredentials({ pin: newPin });
  };

  // Initialisation et abonnement aux flux de données Kinimmo
  useEffect(() => {
    seedInitialFirestoreData();

    // Abonnement aux propriétés
    const unsubProperties = subscribeToProperties((storeProps) => {
      if (Array.isArray(storeProps)) {
        setProperties((currentLocalProps) => {
          const deleted = getDeletedPropertiesIds();
          const durable = getDurableLocalProperties();
          const propsMap = new Map<string, Property>();
          const sanitizeProp = (p: Property): Property => ({
            ...p,
            labels: Array.isArray(p.labels) ? p.labels : [],
            amenities: Array.isArray(p.amenities) ? p.amenities : [],
            images: Array.isArray(p.images) ? p.images : []
          });

          // 1. Charger les propriétés de base et locales
          currentLocalProps.forEach((p) => {
            if (!deleted.has(p.id)) propsMap.set(p.id, sanitizeProp(p));
          });
          durable.forEach((p) => {
            if (!deleted.has(p.id)) propsMap.set(p.id, sanitizeProp(p));
          });

          // 2. Fusionner les propriétés mises à jour
          storeProps.forEach((fp) => {
            if (!deleted.has(fp.id)) {
              propsMap.set(fp.id, sanitizeProp(fp));
            }
          });

          const merged = Array.from(propsMap.values());
          saveDurableLocalProperties(merged);
          return merged;
        });
      }
    });

    // Chargement direct depuis l'API REST MySQL
    mysqlApi.getProperties().then((res: any) => {
      const items = Array.isArray(res?.data) ? res.data : (Array.isArray(res?.properties) ? res.properties : (Array.isArray(res) ? res : null));
      if (items && items.length > 0) {
        setProperties((currentLocalProps) => {
          const deleted = getDeletedPropertiesIds();
          const propsMap = new Map<string, Property>();
          const sanitizeProp = (p: Property): Property => ({
            ...p,
            labels: Array.isArray(p.labels) ? p.labels : [],
            amenities: Array.isArray(p.amenities) ? p.amenities : [],
            images: Array.isArray(p.images) ? p.images : []
          });
          currentLocalProps.forEach((p) => {
            if (!deleted.has(p.id)) propsMap.set(p.id, sanitizeProp(p));
          });
          items.forEach((p: Property) => {
            if (!deleted.has(p.id)) propsMap.set(p.id, sanitizeProp(p));
          });
          const merged = Array.from(propsMap.values());
          saveDurableLocalProperties(merged);
          return merged;
        });
      }
    }).catch(() => {});

    const unsubFields = subscribeToCustomFields((firestoreFields) => {
      if (Array.isArray(firestoreFields)) {
        setCustomFields(firestoreFields);
      }
    });

    const unsubLeads = subscribeToLeads((firestoreLeads) => {
      if (Array.isArray(firestoreLeads)) {
        setLeads(firestoreLeads);
      }
    });

    const unsubInvoices = subscribeToInvoices((firestoreInvoices) => {
      if (Array.isArray(firestoreInvoices)) {
        setInvoices(firestoreInvoices);
      }
    });

    const unsubAgents = subscribeToAgents((firestoreAgents) => {
      if (Array.isArray(firestoreAgents)) {
        setAgents(firestoreAgents);
      }
    });

    const unsubAgencies = subscribeToAgencies((firestoreAgencies) => {
      if (Array.isArray(firestoreAgencies)) {
        setAgencies(firestoreAgencies);
      }
    });

    const unsubUsers = subscribeToUsers((firestoreUsers) => {
      if (Array.isArray(firestoreUsers)) {
        setAllUsers(firestoreUsers);
      }
    });

    const unsubPricing = subscribeToPricingConfig((firestorePricing) => {
      if (firestorePricing) {
        if (typeof firestorePricing.cdfExchangeRate === 'number' && firestorePricing.cdfExchangeRate > 0) {
          setCdfExchangeRate(firestorePricing.cdfExchangeRate);
        }
        if (firestorePricing.pricingDisplayCurrency) {
          setPricingDisplayCurrency(firestorePricing.pricingDisplayCurrency as 'USD' | 'CDF' | 'BOTH');
        }
        if (Array.isArray(firestorePricing.subscriptionPlans) && firestorePricing.subscriptionPlans.length > 0) {
          setSubscriptionPlans(firestorePricing.subscriptionPlans);
        }
      }
    });

    // Synchronize custom fields from MySQL API (Hostinger backend)
    mysqlApi.getCustomFields().then((apiFields) => {
      if (Array.isArray(apiFields) && apiFields.length > 0) {
        setCustomFields(apiFields as CustomFieldDefinition[]);
      }
    }).catch(() => {});

    // Synchronize agencies from MySQL API backend
    mysqlApi.getAgencies().then((res) => {
      if (res && res.success && Array.isArray(res.agencies) && res.agencies.length > 0) {
        setAgencies((prev) => {
          const map = new Map<string, Agency>();
          res.agencies.forEach((a: Agency) => map.set(a.id, a));
          prev.forEach((a) => {
            if (!map.has(a.id)) map.set(a.id, a);
          });
          return Array.from(map.values());
        });
      }
    }).catch(() => {});

    // Synchronize agents from MySQL API backend
    mysqlApi.getAgents().then((res) => {
      if (res && res.success && Array.isArray(res.agents) && res.agents.length > 0) {
        setAgents((prev) => {
          const map = new Map<string, Agent>();
          res.agents.forEach((a: Agent) => map.set(a.id, a));
          prev.forEach((a) => {
            if (!map.has(a.id)) map.set(a.id, a);
          });
          return Array.from(map.values());
        });
      }
    }).catch(() => {});

    return () => {
      unsubProperties();
      unsubFields();
      unsubLeads();
      unsubInvoices();
      unsubAgents();
      unsubAgencies();
      unsubUsers();
      unsubPricing();
    };
  }, []);

  // Sync user profile to Firestore (never password)
  useEffect(() => {
    if (user) {
      saveUserToFirestore(user).catch(err => console.error('Error saving user to Firestore:', err));
    }
  }, [user]);

  // Translate helper
  const t = (key: string): string => {
    return translations[language]?.[key] || translations['fr']?.[key] || key;
  };

  // Custom Fields Actions (Synchronized with MySQL database and protected admin endpoints)
  const addCustomField = (field: CustomFieldDefinition) => {
    setCustomFields((prev) => [...prev, field]);
    mysqlApi.adminCreateCustomField(field).catch(() => {});
    saveCustomFieldToFirestore(field).catch(err => console.error(err));
  };

  const updateCustomField = (field: CustomFieldDefinition) => {
    setCustomFields((prev) => prev.map((f) => (f.id === field.id ? field : f)));
    mysqlApi.adminUpdateCustomField(field.id, field).catch(() => {});
    saveCustomFieldToFirestore(field).catch(err => console.error(err));
  };

  const deleteCustomField = (id: string) => {
    setCustomFields((prev) => prev.filter((f) => f.id !== id));
    mysqlApi.adminDeleteCustomField(id).catch(() => {});
    deleteCustomFieldFromFirestore(id).catch(err => console.error(err));
  };

  // Properties Actions
  const addProperty = async (property: Property) => {
    // Règle métier : la publication d'un bien est strictement réservée aux utilisateurs connectés
    if (!user) {
      throw new Error("Règle métier Kinimmo : Vous devez être connecté pour publier une annonce.");
    }

    // Exécution automatique de l'algorithme de détection des annonces suspectes
    const fraudAnalysis = analyzePropertyForFraud(property, properties, reports);
    const enrichedProperty: Property = {
      ...property,
      agentId: user.agentId || user.id || property.agentId,
      agencyId: user.agencyId || (user.role === 'agency' ? user.id : property.agencyId),
      contactEmail: user.email || property.contactEmail,
      contactPhone: user.phone || property.contactPhone,
      fraudStatus: fraudAnalysis.verdict,
      fraudScore: fraudAnalysis.riskScore,
      fraudFlags: fraudAnalysis.flags,
      fraudLastCheckedAt: fraudAnalysis.analyzedAt,
      // 🟢 Normal & vérification -> publication directe
      // 🔴 Suspect -> blocage temporaire
      published: fraudAnalysis.verdict !== 'suspect' && (property.published !== false)
    };

    setProperties((prev) => {
      const exists = prev.some((p) => p.id === enrichedProperty.id);
      const next = exists ? prev.map((p) => (p.id === enrichedProperty.id ? enrichedProperty : p)) : [enrichedProperty, ...prev];
      saveDurableLocalProperties(next);
      return next;
    });
    // Enregistrement direct dans MySQL via l'API REST
    try {
      const res = await mysqlApi.createProperty(enrichedProperty);
      if (!res.success && res.message && !res.message.includes('Impossible de joindre')) {
        throw new Error(res.message);
      }
    } catch (apiErr: any) {
      if (apiErr.message && !apiErr.message.includes('Impossible de joindre')) {
        throw apiErr;
      }
    }

    try {
      await savePropertyToFirestore(enrichedProperty);
    } catch (err) {
      console.warn('Firestore save property notice (retained in durable storage):', err);
    }
  };

  const updateProperty = async (property: Property) => {
    // Règle métier : la modification d'un bien est strictement réservée aux utilisateurs connectés
    if (!user) {
      throw new Error("Règle métier Kinimmo : Vous devez être connecté pour modifier une annonce.");
    }

    // Ré-analyse lors de toute modification
    const fraudAnalysis = analyzePropertyForFraud(property, properties, reports);
    const enrichedProperty: Property = {
      ...property,
      fraudStatus: fraudAnalysis.verdict,
      fraudScore: fraudAnalysis.riskScore,
      fraudFlags: fraudAnalysis.flags,
      fraudLastCheckedAt: fraudAnalysis.analyzedAt,
      published: fraudAnalysis.verdict !== 'suspect' && (property.published !== false)
    };

    setProperties((prev) => {
      const next = prev.map((p) => (p.id === enrichedProperty.id ? enrichedProperty : p));
      saveDurableLocalProperties(next);
      return next;
    });

    try {
      const res = await mysqlApi.updateProperty(enrichedProperty.id, enrichedProperty);
      if (!res.success && res.message && !res.message.includes('Impossible de joindre')) {
        throw new Error(res.message);
      }
    } catch (apiErr: any) {
      if (apiErr.message && !apiErr.message.includes('Impossible de joindre')) {
        throw apiErr;
      }
    }

    try {
      await savePropertyToFirestore(enrichedProperty);
    } catch (err) {
      console.warn('Firestore update property notice:', err);
    }
  };

  const deleteProperty = (id: string) => {
    markPropertyAsDeletedLocally(id);
    setProperties((prev) => {
      const next = prev.filter((p) => p.id !== id);
      saveDurableLocalProperties(next);
      return next;
    });
    deletePropertyFromFirestore(id).catch((err) => console.error('Firestore delete property error:', err));
  };

  // Règles des annonces : Mise à jour du statut du cycle de vie
  const updatePropertyListingStatus = async (propertyId: string, status: ListingLifecycleStatus, note?: string) => {
    // 1. Enregistrer le nouveau statut côté serveur
    try {
      await mysqlApi.updatePropertyListingStatus(propertyId, status, note);
    } catch (e) {
      console.warn('MySQL API status update notice (fallback local durable):', e);
    }

    // 2. Mettre à jour immédiatement les données du tableau de bord
    let updatedPropertyObj: Property | null = null;
    setProperties((prev) => {
      const next = prev.map((p) => {
        if (p.id === propertyId) {
          const oldStatus = p.listingStatus || (p.status === 'sold' ? 'SOLD' : 'PUBLISHED');
          const historyEntry = createStatusHistoryEntry(oldStatus, status, user, note);
          const history = Array.isArray(p.statusHistory) ? [...p.statusHistory, historyEntry] : [historyEntry];

          const isAvailable = status === 'PUBLISHED';
          const legacyStatus = status === 'SOLD' ? 'sold' : (status === 'RENTED' ? 'for-rent' : p.status);

          const updated: Property = {
            ...p,
            listingStatus: status,
            isAvailable,
            status: legacyStatus,
            published: status === 'PUBLISHED',
            statusHistory: history,
            updatedAt: new Date().toISOString()
          };
          updatedPropertyObj = updated;
          return updated;
        }
        return p;
      });
      saveDurableLocalProperties(next);
      return next;
    });

    if (updatedPropertyObj) {
      savePropertyToFirestore(updatedPropertyObj).catch(() => {});
    }

    return {
      success: true,
      message: `Statut du bien mis à jour vers ${status}.`
    };
  };

  const assignPropertyToAgent = async (propertyId: string, assignedAgentId: string, assignedAgentName: string) => {
    try {
      await mysqlApi.assignProperty(propertyId, assignedAgentId, assignedAgentName);
    } catch (e) {}

    setProperties((prev) => {
      const next = prev.map((p) => {
        if (p.id === propertyId) {
          return {
            ...p,
            assignedAgentId,
            assignedAgentName,
            updatedAt: new Date().toISOString()
          };
        }
        return p;
      });
      saveDurableLocalProperties(next);
      return next;
    });
  };

  // Collaborateurs d'agence
  const COLLABORATORS_STORAGE_KEY = 'kinimmo_agency_collaborators_store';
  const [agencyCollaborators, setAgencyCollaborators] = useState<AgencyCollaborator[]>(() => {
    try {
      const saved = localStorage.getItem(COLLABORATORS_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'collab_dieudonne',
        agencyId: 'agency_congo_luxury',
        userId: 'usr_dieudonne_01',
        name: 'Dieudonné Mwamba',
        email: 'dieudonne@congoluxuryhomes.cd',
        phone: '+243 81 000 0001',
        whatsapp: '+243 81 000 0001',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        role: 'agency_owner',
        permissions: { canEditAllProperties: true, canAssignProperties: true, canAssignLeads: true, canViewBilling: true, canManageTeam: true },
        status: 'active',
        invitedAt: '2026-01-01T08:00:00Z',
        joinedAt: '2026-01-01T08:30:00Z',
        activeListingsCount: 12,
        totalLeadsCount: 48
      },
      {
        id: 'collab_patrick',
        agencyId: 'agency_immo_kinshasa',
        userId: 'usr_patrick_02',
        name: 'Patrick Kalombo',
        email: 'patrick@immokingombe.cd',
        phone: '+243 82 123 4567',
        whatsapp: '+243 82 123 4567',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        role: 'agency_manager',
        permissions: { canEditAllProperties: true, canAssignProperties: true, canAssignLeads: true, canViewBilling: false, canManageTeam: true },
        status: 'active',
        invitedAt: '2026-01-10T09:00:00Z',
        joinedAt: '2026-01-10T10:00:00Z',
        activeListingsCount: 8,
        totalLeadsCount: 32
      },
      {
        id: 'collab_sarah',
        agencyId: 'agency_fleuve_habitat',
        userId: 'usr_sarah_03',
        name: 'Sarah Mbuyi',
        email: 'sarah@fleuvecongoimmo.cd',
        phone: '+243 99 876 5432',
        whatsapp: '+243 99 876 5432',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
        role: 'agency_agent',
        permissions: { canEditAllProperties: false, canAssignProperties: false, canAssignLeads: false, canViewBilling: false, canManageTeam: false },
        status: 'active',
        invitedAt: '2026-02-01T11:00:00Z',
        joinedAt: '2026-02-02T09:15:00Z',
        activeListingsCount: 5,
        totalLeadsCount: 19
      }
    ];
  });

  const saveCollaboratorsLocally = (collabs: AgencyCollaborator[]) => {
    try {
      localStorage.setItem(COLLABORATORS_STORAGE_KEY, JSON.stringify(collabs));
    } catch {}
  };

  const inviteAgencyCollaborator = async (data: any) => {
    const newCollab: AgencyCollaborator = {
      id: `collab_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      agencyId: data.agencyId || user?.agencyId || user?.id || 'agency_default',
      userId: `usr_${Date.now()}`,
      name: data.name,
      email: data.email,
      phone: data.phone || '',
      whatsapp: data.whatsapp || data.phone || '',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      role: data.role || 'agency_agent',
      permissions: data.permissions || { canEditAllProperties: false, canAssignProperties: false, canAssignLeads: false, canViewBilling: false, canManageTeam: false },
      status: 'invited',
      invitedAt: new Date().toISOString(),
      activeListingsCount: 0,
      totalLeadsCount: 0
    };

    setAgencyCollaborators((prev) => {
      const next = [newCollab, ...prev];
      saveCollaboratorsLocally(next);
      return next;
    });

    try {
      await mysqlApi.inviteAgencyCollaborator(newCollab);
    } catch {}

    return { success: true, message: `Collaborateur ${data.name} invité avec succès.`, collaborator: newCollab };
  };

  const updateAgencyCollaborator = async (id: string, data: Partial<AgencyCollaborator>) => {
    setAgencyCollaborators((prev) => {
      const next = prev.map((c) => (c.id === id ? { ...c, ...data } : c));
      saveCollaboratorsLocally(next);
      return next;
    });
    try {
      await mysqlApi.updateAgencyCollaborator(id, data);
    } catch {}
  };

  const deleteAgencyCollaborator = async (id: string) => {
    setAgencyCollaborators((prev) => {
      const next = prev.filter((c) => c.id !== id);
      saveCollaboratorsLocally(next);
      return next;
    });
    try {
      await mysqlApi.deleteAgencyCollaborator(id);
    } catch {}
  };

  // Transactions d'agence
  const TRANSACTIONS_STORAGE_KEY = 'kinimmo_agency_transactions_store';
  const [agencyTransactions, setAgencyTransactions] = useState<AgencyTransaction[]>(() => {
    try {
      const saved = localStorage.getItem(TRANSACTIONS_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'tx_001',
        agencyId: 'agency_congo_luxury',
        propertyId: 'prop_1',
        propertyTitle: 'Villa Diplomatique Haute Sécurité avec Piscine',
        agentId: 'collab_dieudonne',
        agentName: 'Dieudonné Mwamba',
        clientName: 'Ambassade & Mission Diplomatique',
        clientContact: '+243 81 999 8888',
        type: 'sale',
        amount: 1250000,
        currency: 'USD',
        commissionRate: 5.0,
        commissionAmount: 62500,
        status: 'closed',
        notes: 'Acte notarié signé avec succès à la Gombe.',
        closedAt: '2026-09-15T14:00:00Z',
        createdAt: '2026-08-20T10:00:00Z'
      },
      {
        id: 'tx_002',
        agencyId: 'agency_immo_kinshasa',
        propertyId: 'prop_2',
        propertyTitle: 'Appartement Haut Standing Vue Fleuve',
        agentId: 'collab_patrick',
        agentName: 'Patrick Kalombo',
        clientName: 'Directeur Général Multinationale Télécom',
        clientContact: '+243 82 555 4444',
        type: 'rent',
        amount: 3500,
        currency: 'USD',
        commissionRate: 100.0,
        commissionAmount: 3500,
        status: 'closed',
        notes: 'Bail locatif d\'un an renouvelable.',
        closedAt: '2026-10-01T16:30:00Z',
        createdAt: '2026-09-25T11:00:00Z'
      }
    ];
  });

  const saveTransactionsLocally = (txs: AgencyTransaction[]) => {
    try {
      localStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(txs));
    } catch {}
  };

  const createAgencyTransaction = async (data: any) => {
    const newTx: AgencyTransaction = {
      id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      agencyId: data.agencyId || user?.agencyId || user?.id || 'agency_default',
      propertyId: data.propertyId || '',
      propertyTitle: data.propertyTitle || 'Propriété Kinshasa',
      agentId: data.agentId || user?.id || 'agent_current',
      agentName: data.agentName || user?.name || 'Agent Immobilier',
      clientName: data.clientName || 'Client Particulier',
      clientContact: data.clientContact || '',
      type: data.type || 'sale',
      amount: Number(data.amount) || 0,
      currency: data.currency || 'USD',
      commissionRate: Number(data.commissionRate) || 5,
      commissionAmount: Number(data.commissionAmount) || (Number(data.amount || 0) * 0.05),
      status: data.status || 'closed',
      notes: data.notes || '',
      closedAt: data.closedAt || new Date().toISOString(),
      createdAt: new Date().toISOString()
    };

    setAgencyTransactions((prev) => {
      const next = [newTx, ...prev];
      saveTransactionsLocally(next);
      return next;
    });

    try {
      await mysqlApi.createAgencyTransaction(newTx);
    } catch {}

    return { success: true, transaction: newTx };
  };

  // Agent Actions
  const addAgent = (agent: Agent) => {
    setAgents((prev) => [agent, ...prev]);
    saveAgentToFirestore(agent).catch((err) => console.error('Firestore save agent error:', err));
  };

  const updateAgent = (agent: Agent) => {
    setAgents((prev) => prev.map((a) => (a.id === agent.id ? agent : a)));
    saveAgentToFirestore(agent).catch((err) => console.error('Firestore update agent error:', err));
  };

  const deleteAgent = (id: string) => {
    setAgents((prev) => prev.filter((a) => a.id !== id));
    deleteAgentFromFirestore(id).catch((err) => console.error('Firestore delete agent error:', err));
  };

  const toggleAgentVisibility = (agentId: string) => {
    let updatedAgentObj: Agent | null = null;
    setAgents((prev) => {
      const updated = prev.map((a) => {
        if (a.id === agentId || (a.email && a.email.toLowerCase() === agentId.toLowerCase())) {
          const updatedA = { ...a, isHidden: !a.isHidden };
          updatedAgentObj = updatedA;
          return updatedA;
        }
        return a;
      });
      return updated;
    });
    if (updatedAgentObj) {
      saveAgentToFirestore(updatedAgentObj).catch((err) => console.error('Firestore toggle agent visibility error:', err));
    }
  };

  // Agent Verification Management (Admin & Pro Agent)
  const updateAgentVerification = (
    agentId: string,
    isVerified: boolean,
    verificationStatus: 'unverified' | 'pending' | 'verified' | 'rejected',
    rejectionReason?: string,
    verifiedBy?: string
  ) => {
    const now = new Date().toISOString();
    let updatedAgentObj: Agent | null = null;

    setAgents((prev) => {
      const updated = prev.map((a) => {
        if (a.id === agentId || (a.email && a.email.toLowerCase() === agentId.toLowerCase())) {
          const updatedDocList = (a.verificationDocuments || []).map((doc) => ({
            ...doc,
            status: verificationStatus === 'verified' ? ('approved' as const) : verificationStatus === 'rejected' ? ('rejected' as const) : doc.status,
            verifiedAt: verificationStatus === 'verified' ? now : doc.verifiedAt,
            verifiedBy: verificationStatus === 'verified' ? (verifiedBy || 'Admin Immocraft') : doc.verifiedBy,
          }));

          const updatedAgent: Agent = {
            ...a,
            isVerified,
            verificationStatus,
            verifiedAt: isVerified ? now : undefined,
            verifiedBy: isVerified ? (verifiedBy || 'Direction Immocraft RDC (Admin Audit)') : undefined,
            rejectionReason: verificationStatus === 'rejected' ? rejectionReason : undefined,
            verificationDocuments: updatedDocList,
          };
          updatedAgentObj = updatedAgent;
          return updatedAgent;
        }
        return a;
      });

      return updated;
    });

    if (updatedAgentObj) {
      saveAgentToFirestore(updatedAgentObj).catch((err) => console.error('Firestore save agent verification error:', err));
    }

    // Sync with allUsers in case the agent is a registered user
    setAllUsers((prevUsers) => {
      const updatedUsers = prevUsers.map((u) => {
        if (u.id === agentId || u.agentId === agentId || (u.email && u.email.toLowerCase() === agentId.toLowerCase())) {
          const updatedUser: User = {
            ...u,
            isVerified,
            verificationStatus,
            verifiedAt: isVerified ? now : undefined,
            verifiedBy: isVerified ? (verifiedBy || 'Direction Immocraft RDC') : undefined,
            rejectionReason: verificationStatus === 'rejected' ? rejectionReason : undefined,
            kinshasaBadgeVerified: isVerified,
          };
          saveUserToFirestore(updatedUser).catch((err) => console.error('Firestore save user verification error:', err));
          return updatedUser;
        }
        return u;
      });
      return updatedUsers;
    });

    // Update logged in user if matching
    if (user && (user.id === agentId || user.agentId === agentId || (user.email && user.email.toLowerCase() === agentId.toLowerCase()))) {
      setUser((prev) => prev ? ({
        ...prev,
        isVerified,
        verificationStatus,
        verifiedAt: isVerified ? now : undefined,
        verifiedBy: isVerified ? (verifiedBy || 'Direction Immocraft RDC') : undefined,
        rejectionReason: verificationStatus === 'rejected' ? rejectionReason : undefined,
        kinshasaBadgeVerified: isVerified,
      }) : null);
    }
  };

  const updateAgentVerificationDocument = (
    agentId: string,
    docId: string,
    status: 'approved' | 'rejected',
    rejectionNote?: string
  ) => {
    const now = new Date().toISOString();
    let updatedAgentObj: Agent | null = null;

    setAgents((prev) => {
      const updated = prev.map((a) => {
        if (a.id === agentId || (a.email && a.email.toLowerCase() === agentId.toLowerCase())) {
          const updatedDocs = (a.verificationDocuments || []).map((doc) => {
            if (doc.id === docId) {
              return {
                ...doc,
                status,
                rejectionNote: status === 'rejected' ? rejectionNote : undefined,
                verifiedAt: status === 'approved' ? now : undefined,
                verifiedBy: status === 'approved' ? 'Admin Immocraft' : undefined,
              };
            }
            return doc;
          });

          // Check if all documents are approved
          const allApproved = updatedDocs.length > 0 && updatedDocs.every((d) => d.status === 'approved');
          const hasRejected = updatedDocs.some((d) => d.status === 'rejected');

          const newVerificationStatus: 'unverified' | 'pending' | 'verified' | 'rejected' = allApproved
            ? 'verified'
            : hasRejected
            ? 'rejected'
            : 'pending';

          const updatedAgent: Agent = {
            ...a,
            verificationDocuments: updatedDocs,
            isVerified: allApproved,
            verificationStatus: newVerificationStatus,
            verifiedAt: allApproved ? now : a.verifiedAt,
            verifiedBy: allApproved ? 'Direction Immocraft RDC' : a.verifiedBy,
          };
          updatedAgentObj = updatedAgent;
          return updatedAgent;
        }
        return a;
      });

      return updated;
    });

    if (updatedAgentObj) {
      saveAgentToFirestore(updatedAgentObj).catch((err) => console.error('Firestore save agent doc status error:', err));
    }
  };

  const submitAgentVerificationDocuments = (
    agentId: string,
    documents: import('../types').VerificationDocument[],
    identityDocType?: any,
    identityDocNumber?: string,
    rccmOrNif?: string
  ) => {
    const now = new Date().toISOString();
    let updatedAgentObj: Agent | null = null;

    setAgents((prev) => {
      let found = false;
      const updated = prev.map((a) => {
        if (a.id === agentId || (a.email && a.email.toLowerCase() === agentId.toLowerCase())) {
          found = true;
          const mergedDocs = [...(a.verificationDocuments || []), ...documents];
          const updatedAgent: Agent = {
            ...a,
            verificationStatus: 'pending',
            isVerified: false,
            verificationRequestedAt: now,
            identityDocType: identityDocType || a.identityDocType,
            identityDocNumber: identityDocNumber || a.identityDocNumber,
            rccmOrNif: rccmOrNif || a.rccmOrNif,
            verificationDocuments: mergedDocs,
            rejectionReason: undefined,
          };
          updatedAgentObj = updatedAgent;
          return updatedAgent;
        }
        return a;
      });

      if (!found && user) {
        // Create new agent entry if it didn't exist
        const newAgent: Agent = {
          id: agentId,
          name: user.name || 'Agent Immobilier',
          title: 'Agent Immobilier Agréé',
          email: user.email || '',
          phone: user.phone || '+243 81 000 0000',
          whatsapp: user.whatsapp || user.phone || '+243 81 000 0000',
          avatar: user.avatar || 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=300&auto=format&fit=crop&q=80',
          agencyName: user.agencyName || 'Indépendant Kinshasa',
          rating: 5.0,
          reviewCount: 1,
          listingsCount: 0,
          bio: 'Agent immobilier partenaire certifié Immocraft Kinshasa.',
          specialties: ['Résidentiel', 'Commercial'],
          languages: ['Français', 'Lingala'],
          verificationStatus: 'pending',
          isVerified: false,
          verificationRequestedAt: now,
          identityDocType,
          identityDocNumber,
          rccmOrNif,
          verificationDocuments: documents,
        };
        updated.push(newAgent);
        updatedAgentObj = newAgent;
      }

      return updated;
    });

    if (updatedAgentObj) {
      saveAgentToFirestore(updatedAgentObj).catch((err) => console.error('Firestore save agent submitted docs error:', err));
    }

    // Sync logged in user
    if (user && (user.id === agentId || user.agentId === agentId || (user.email && user.email.toLowerCase() === agentId.toLowerCase()))) {
      setUser((prev) => prev ? ({
        ...prev,
        verificationStatus: 'pending',
        isVerified: false,
        verificationRequestedAt: now,
        identityDocType,
        identityDocNumber,
        rccmOrNif,
        verificationDocuments: documents,
        rejectionReason: undefined,
      }) : null);
    }
  };

  // Agency (Concessionnaire) Actions
  const addAgency = (agency: Agency) => {
    const nextExpiry = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const agencyWithFreeTrial: Agency = {
      ...agency,
      subscriptionStatus: 'Active',
      subscriptionExpiresAt: agency.subscriptionExpiresAt || nextExpiry,
      lastPaymentDate: new Date().toISOString().split('T')[0],
    };

    setAgencies((prev) => [agencyWithFreeTrial, ...prev]);
    saveAgencyToFirestore(agencyWithFreeTrial).catch((err) => console.error('Firestore save agency error:', err));

    // Auto-generate 1 month free welcome invoice ($0)
    const promoInvoice: Invoice = {
      id: `inv_free_${Date.now()}`,
      invoiceNumber: `KIN-FREE-${Math.floor(1000 + Math.random() * 9000)}`,
      targetType: 'agency',
      targetId: agencyWithFreeTrial.id,
      targetName: agencyWithFreeTrial.name,
      targetEmail: agencyWithFreeTrial.email,
      targetPhone: agencyWithFreeTrial.phone,
      planId: 'agency',
      items: [
        {
          id: `item_free_${Date.now()}`,
          description: `Abonnement Agence Immobilière - 1er Mois Gratuit (Offre Spéciale de Bienvenue)`,
          amount: 0,
          quantity: 1
        }
      ],
      subtotalAmount: 0,
      taxAmount: 0,
      totalAmount: 0,
      currency: 'USD',
      status: 'paid',
      paymentMethod: 'orange_money',
      dueDate: nextExpiry,
      createdAt: new Date().toISOString(),
      paidAt: new Date().toISOString(),
      notes: 'Offre spéciale de bienvenue : 1 mois d\'abonnement offert gratuitement à toute nouvelle agence.'
    };

    setInvoices((prev) => [promoInvoice, ...prev]);
    saveInvoiceToFirestore(promoInvoice).catch(err => console.error(err));
  };

  const updateAgency = (agency: Agency) => {
    setAgencies((prev) => prev.map((a) => (a.id === agency.id ? agency : a)));
    saveAgencyToFirestore(agency).catch((err) => console.error('Firestore update agency error:', err));
  };

  const deleteAgency = (id: string) => {
    setAgencies((prev) => prev.filter((a) => a.id !== id));
    deleteAgencyFromFirestore(id).catch((err) => console.error('Firestore delete agency error:', err));
  };

  const toggleAgencyVisibility = (agencyId: string) => {
    let updatedAgencyObj: Agency | null = null;
    setAgencies((prev) => {
      const updated = prev.map((ag) => {
        if (ag.id === agencyId || ag.name.toLowerCase() === agencyId.toLowerCase()) {
          const updatedAg = { ...ag, isHidden: !ag.isHidden };
          updatedAgencyObj = updatedAg;
          return updatedAg;
        }
        return ag;
      });
      return updated;
    });
    if (updatedAgencyObj) {
      saveAgencyToFirestore(updatedAgencyObj).catch((err) => console.error('Firestore toggle agency visibility error:', err));
    }
  };

  // Subscription Plans Management (CDF & USD)
  const updateSubscriptionPlan = (plan: SubscriptionPlan) => {
    setSubscriptionPlans((prev) => {
      const updated = prev.map((p) => (p.id === plan.id ? plan : p));
      savePricingConfigToFirestore({
        cdfExchangeRate,
        pricingDisplayCurrency,
        subscriptionPlans: updated,
      }).catch(err => console.error('Firestore save pricing config error:', err));
      return updated;
    });
  };

  const addSubscriptionPlan = (plan: SubscriptionPlan) => {
    setSubscriptionPlans((prev) => {
      const updated = [...prev, plan];
      savePricingConfigToFirestore({
        cdfExchangeRate,
        pricingDisplayCurrency,
        subscriptionPlans: updated,
      }).catch(err => console.error('Firestore add pricing config error:', err));
      return updated;
    });
  };

  const deleteSubscriptionPlan = (id: string) => {
    setSubscriptionPlans((prev) => {
      const updated = prev.filter((p) => p.id !== id);
      savePricingConfigToFirestore({
        cdfExchangeRate,
        pricingDisplayCurrency,
        subscriptionPlans: updated,
      }).catch(err => console.error('Firestore delete pricing plan error:', err));
      return updated;
    });
  };

  const handleSetCdfExchangeRate = (rate: number) => {
    if (typeof rate === 'number' && rate > 0) {
      setCdfExchangeRate(rate);
      savePricingConfigToFirestore({
        cdfExchangeRate: rate,
        pricingDisplayCurrency,
        subscriptionPlans,
      }).catch(err => console.error('Firestore save cdf exchange rate error:', err));
    }
  };

  const handleSetPricingDisplayCurrency = (currency: 'CDF' | 'USD' | 'BOTH') => {
    setPricingDisplayCurrency(currency);
    savePricingConfigToFirestore({
      cdfExchangeRate,
      pricingDisplayCurrency: currency,
      subscriptionPlans,
    }).catch(err => console.error('Firestore save pricing display currency error:', err));
  };

  const updateAgencySubscriptionStatus = (agencyId: string, status: 'Active' | 'Expired', expiresAt?: string) => {
    const nextExpiry = expiresAt || (status === 'Active'
      ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      : new Date().toISOString().split('T')[0]);

    setAgencies((prev) => {
      const updated = prev.map((ag) => {
        if (ag.id === agencyId || ag.name.toLowerCase() === agencyId.toLowerCase() || ag.email?.toLowerCase() === agencyId.toLowerCase()) {
          const updatedAg: Agency = {
            ...ag,
            subscriptionStatus: status,
            subscriptionExpiresAt: nextExpiry,
            ...(status === 'Active' ? { unpaidInvoiceId: undefined } : {})
          };
          saveAgencyToFirestore(updatedAg).catch((err) => console.error('Firestore update agency subscription status error:', err));
          return updatedAg;
        }
        return ag;
      });
      return updated;
    });

    // Also sync user if logged in under this agency
    if (user && (user.agencyId === agencyId || (user.agencyName && user.agencyName.toLowerCase() === agencyId.toLowerCase()))) {
      const updatedUser: User = {
        ...user,
        subscriptionStatus: status,
        subscriptionExpiresAt: nextExpiry,
      };
      setUser(updatedUser);
      saveUserToFirestore(updatedUser).catch((err) => console.error('Firestore update user error:', err));
    }
  };

  const updateUserSubscriptionStatus = (targetIdOrEmail: string, status: 'Active' | 'Expired', expiresAt?: string) => {
    const nextExpiry = expiresAt || (status === 'Active'
      ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      : new Date().toISOString().split('T')[0]);

    setAgents((prev) => {
      const updated = prev.map((agt) => {
        if (agt.id === targetIdOrEmail || agt.email?.toLowerCase() === targetIdOrEmail.toLowerCase()) {
          const updatedAgt: Agent = {
            ...agt,
            subscriptionStatus: status,
            subscriptionExpiresAt: nextExpiry,
          };
          saveAgentToFirestore(updatedAgt).catch((err) => console.error('Firestore update agent error:', err));
          return updatedAgt;
        }
        return agt;
      });
      return updated;
    });

    if (user && (user.id === targetIdOrEmail || user.email?.toLowerCase() === targetIdOrEmail.toLowerCase())) {
      const updatedUser: User = {
        ...user,
        subscriptionStatus: status,
        subscriptionExpiresAt: nextExpiry,
      };
      setUser(updatedUser);
      saveUserToFirestore(updatedUser).catch((err) => console.error('Firestore update user error:', err));
    }
  };

  // Wishlist Actions
  const toggleWishlist = (propertyId: string) => {
    setWishlist((prev) =>
      prev.includes(propertyId)
        ? prev.filter((id) => id !== propertyId)
        : [...prev, propertyId]
    );
  };

  // Compare Actions
  const toggleCompare = (propertyId: string) => {
    setCompareList((prev) =>
      prev.includes(propertyId)
        ? prev.filter((id) => id !== propertyId)
        : prev.length >= 4
        ? prev // Limit max 4 properties
        : [...prev, propertyId]
    );
  };

  const clearCompare = () => {
    setCompareList([]);
  };

  // Saved Search Actions
  const addSavedSearch = (title: string, notifyFrequency: SavedSearch['notifyFrequency']) => {
    const newSearch: SavedSearch = {
      id: `search_${Date.now()}`,
      userId: user?.id || 'guest',
      title: title || `${filters.city || 'Toutes Villes'} - ${filters.type}`,
      filters: { ...filters },
      notifyFrequency,
      createdAt: new Date().toISOString(),
    };
    setSavedSearches((prev) => [newSearch, ...prev]);
  };

  const deleteSavedSearch = (id: string) => {
    setSavedSearches((prev) => prev.filter((s) => s.id !== id));
  };

  // Leads Actions
  const addLeadRequest = (lead: Omit<LeadRequest, 'id' | 'createdAt' | 'status'>) => {
    const newLead: LeadRequest = {
      ...lead,
      id: `lead_${Date.now()}`,
      status: 'new',
      createdAt: new Date().toISOString(),
    };
    setLeads((prev) => [newLead, ...prev]);
    saveLeadToFirestore(newLead).catch(err => console.error(err));
  };

  const updateLeadStatus = (leadId: string, status: LeadRequest['status']) => {
    setLeads((prev) => {
      const updated = prev.map((l) => (l.id === leadId ? { ...l, status } : l));
      const targetLead = updated.find((l) => l.id === leadId);
      if (targetLead) {
        saveLeadToFirestore(targetLead).catch(err => console.error(err));
      }
      return updated;
    });
  };

  const deleteLead = (id: string) => {
    setLeads((prev) => prev.filter((l) => l.id !== id));
    deleteLeadFromFirestore(id).catch(err => console.error(err));
  };

  const deleteUser = (id: string) => {
    if (user && (user.id === id || user.email === id)) {
      setUser(null);
    }
    deleteUserFromFirestore(id).catch((err) => console.error(err));
  };

  // Invoices Actions
  const addInvoice = (invoice: Invoice) => {
    setInvoices((prev) => [invoice, ...prev]);
    saveInvoiceToFirestore(invoice).catch(err => console.error(err));
  };

  const updateInvoice = (updatedInvoice: Invoice) => {
    setInvoices((prev) => prev.map((inv) => (inv.id === updatedInvoice.id ? updatedInvoice : inv)));
    saveInvoiceToFirestore(updatedInvoice).catch(err => console.error(err));
  };

  const updateInvoiceStatus = (id: string, status: Invoice['status'], paymentMethod?: Invoice['paymentMethod'], notes?: string) => {
    setInvoices((prev) => {
      const updated = prev.map((inv) => {
        if (inv.id === id) {
          const updatedInv: Invoice = {
            ...inv,
            status,
            ...(paymentMethod ? { paymentMethod } : {}),
            ...(notes ? { notes } : {}),
            ...(status === 'paid' ? { paidAt: new Date().toISOString() } : {})
          };
          saveInvoiceToFirestore(updatedInv).catch(err => console.error(err));

          // Auto update subscription status of target
          if (status === 'paid') {
            const nextExpiry = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
            if (inv.targetType === 'agency' || inv.targetId.startsWith('agency_')) {
              updateAgencySubscriptionStatus(inv.targetId, 'Active', nextExpiry);
            }
            updateUserSubscriptionStatus(inv.targetId, 'Active', nextExpiry);
            if (inv.targetEmail) {
              updateUserSubscriptionStatus(inv.targetEmail, 'Active', nextExpiry);
            }

            // Activation automatique du boost sur la propriété après validation du paiement par l'administrateur
            const anyInv = inv as any;
            const targetPropId = anyInv.propertyId || anyInv.property_id || (String(anyInv.targetType) === 'property' ? inv.targetId : null);
            if (targetPropId) {
              const optionId = String(anyInv.optionId || anyInv.option_id || '').toLowerCase();
              let durationDays = 7;
              if (optionId.includes('30')) durationDays = 30;
              else if (optionId.includes('14')) durationDays = 14;
              else if (optionId.includes('7')) durationDays = 7;

              const expiresAt = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString();

              setProperties((curr) => {
                const updatedProps = curr.map((p) => {
                  if (p.id === targetPropId) {
                    const isPrem = optionId.includes('premium');
                    const isFeat = optionId.includes('featured') || isPrem;
                    const isUrg = optionId.includes('urgent');
                    return {
                      ...p,
                      boostExpiresAt: expiresAt,
                      featured: isFeat || p.featured,
                      isPremium: isPrem || p.isPremium,
                      isUrgent: isUrg || p.isUrgent,
                      listingTier: isPrem ? 'premium' : (isFeat ? 'featured' : p.listingTier),
                      refreshBumpAt: new Date().toISOString(),
                      updatedAt: new Date().toISOString()
                    };
                  }
                  return p;
                });
                saveDurableLocalProperties(updatedProps);
                return updatedProps;
              });

              // Projection automatique dans la Vitrine Hero
              promotePropertyToHero(targetPropId);
            }
          } else if (status === 'overdue' || status === 'cancelled') {
            if (inv.targetType === 'agency' || inv.targetId.startsWith('agency_')) {
              updateAgencySubscriptionStatus(inv.targetId, 'Expired');
            }
            updateUserSubscriptionStatus(inv.targetId, 'Expired');
            if (inv.targetEmail) {
              updateUserSubscriptionStatus(inv.targetEmail, 'Expired');
            }
          }

          return updatedInv;
        }
        return inv;
      });
      return updated;
    });
  };

  const deleteInvoice = (id: string) => {
    setInvoices((prev) => prev.filter((inv) => inv.id !== id));
    deleteInvoiceFromFirestore(id).catch(err => console.error(err));
  };

  const resetFilters = () => {
    setFilters(defaultFilters);
  };

  // CSV Import / Export
  const importCSV = (csvContent: string) => {
    Papa.parse(csvContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const imported: Property[] = results.data.map((row: any, idx: number) => ({
          id: `prop_csv_${Date.now()}_${idx}`,
          title: row.title || 'Propriété Importée',
          description: row.description || 'Description importée via CSV',
          price: Number(row.price) || 500000,
          currency: row.currency || 'EUR',
          type: row.type || 'apartment',
          status: row.status || 'for-sale',
          labels: row.labels ? row.labels.split(';') : ['new'],
          category: row.category || 'Général',
          address: row.address || 'Adresse Inconnue',
          city: row.city || 'Paris',
          zipCode: row.zipCode || '75000',
          country: row.country || 'France',
          lat: Number(row.lat) || 48.8566,
          lng: Number(row.lng) || 2.3522,
          bedrooms: Number(row.bedrooms) || 2,
          bathrooms: Number(row.bathrooms) || 1,
          area: Number(row.area) || 75,
          amenities: row.amenities ? row.amenities.split(';') : ['Ascenseur'],
          images: row.images ? row.images.split(';') : ['https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&auto=format&fit=crop&q=80'],
          customFields: {},
          agentId: user?.agentId || 'agent_1',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          viewsCount: 1,
          featured: false,
          published: true,
        }));

        setProperties((prev) => [...imported, ...prev]);
      },
    });
  };

  const exportCSV = () => {
    const csvData = properties.map((p) => ({
      id: p.id,
      title: p.title,
      price: p.price,
      currency: p.currency,
      type: p.type,
      status: p.status,
      city: p.city,
      address: p.address,
      bedrooms: p.bedrooms,
      bathrooms: p.bathrooms,
      area: p.area,
      viewsCount: p.viewsCount,
    }));

    const csv = Papa.unparse(csvData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `ImmoCraft_Properties_Export_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    if (link.parentNode) {
      link.parentNode.removeChild(link);
    } else {
      link.remove();
    }
  };

  // Google Analytics & Property View Incrementing
  const incrementPropertyViews = (propertyId: string) => {
    setProperties((prev) => {
      const updated = prev.map((p) => {
        if (p.id === propertyId) {
          const updatedProp: Property = {
            ...p,
            viewsCount: (p.viewsCount || 0) + 1,
            lastViewedAt: new Date().toISOString()
          };
          trackPropertyView(updatedProp);
          savePropertyToFirestore(updatedProp).catch((err) =>
            console.error('Firestore increment views error:', err)
          );
          return updatedProp;
        }
        return p;
      });
      return updated;
    });
  };

  const recordPropertyAction = (propertyId: string, action: 'whatsapp' | 'call' | 'lead' | 'share') => {
    setProperties((prev) => {
      const updated = prev.map((p) => {
        if (p.id === propertyId) {
          const updatedProp: Property = {
            ...p,
            whatsappClicks: action === 'whatsapp' ? (p.whatsappClicks || 0) + 1 : p.whatsappClicks,
            phoneCalls: action === 'call' ? (p.phoneCalls || 0) + 1 : p.phoneCalls,
            leadsCount: action === 'lead' ? (p.leadsCount || 0) + 1 : p.leadsCount,
            sharesCount: action === 'share' ? (p.sharesCount || 0) + 1 : p.sharesCount
          };
          trackContactClick(action === 'whatsapp' ? 'whatsapp' : action === 'call' ? 'call' : 'email', updatedProp);
          savePropertyToFirestore(updatedProp).catch((err) =>
            console.error('Firestore record action error:', err)
          );
          return updatedProp;
        }
        return p;
      });
      return updated;
    });
  };

  const handleSetActivePropertyModalId = (id: string | null) => {
    setActivePropertyModalId(id);
    if (id) {
      incrementPropertyViews(id);
      const prop = properties.find((p) => p.id === id);
      updateBrowserUrlForProperty(id, prop?.title);
    } else {
      updateBrowserUrlForProperty(null);
    }
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        currency,
        setCurrency,
        t,
        user,
        setUser,
        deleteUser,
        allUsers,
        logOut,
        invitedRole,
        invitedBy,
        clearInvite,
        isInviteModalOpen,
        setIsInviteModalOpen,
        customFields,
        addCustomField,
        updateCustomField,
        deleteCustomField,
        properties,
        addProperty,
        updateProperty,
        deleteProperty,
        agents,
        addAgent,
        updateAgent,
        deleteAgent,
        toggleAgentVisibility,
        updateAgentVerification,
        updateAgentVerificationDocument,
        submitAgentVerificationDocuments,
        agencies,
        addAgency,
        updateAgency,
        deleteAgency,
        toggleAgencyVisibility,
        updateAgencySubscriptionStatus,
        updateUserSubscriptionStatus,
        subscriptionPlans,
        updateSubscriptionPlan,
        addSubscriptionPlan,
        deleteSubscriptionPlan,
        pricingDisplayCurrency,
        setPricingDisplayCurrency: handleSetPricingDisplayCurrency,
        cdfExchangeRate,
        setCdfExchangeRate: handleSetCdfExchangeRate,
        wishlist,
        toggleWishlist,
        compareList,
        toggleCompare,
        clearCompare,
        savedSearches,
        addSavedSearch,
        deleteSavedSearch,
        leads,
        addLeadRequest,
        updateLeadStatus,
        deleteLead,
        invoices,
        addInvoice,
        updateInvoice,
        updateInvoiceStatus,
        deleteInvoice,
        adminPin,
        updateAdminPin,
        filters,
        setFilters,
        resetFilters,
        activePropertyModalId,
        setActivePropertyModalId: handleSetActivePropertyModalId,
        isFieldsBuilderOpen,
        setIsFieldsBuilderOpen,
        isSubmitPropertyOpen,
        setIsSubmitPropertyOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isSecurityModalOpen,
        setIsSecurityModalOpen,
        isCompareOpen,
        setIsCompareOpen,
        editingProperty,
        setEditingProperty,
        importCSV,
        exportCSV,
        googleAnalyticsId,
        updateGoogleAnalyticsId,
        incrementPropertyViews,
        recordPropertyAction,
        requestConfirm,
        heroSlides,
        setHeroSlides,
        addHeroSlide,
        updateHeroSlide,
        deleteHeroSlide,
        promotePropertyToHero,
        removePropertyFromHero,
        contactSettings,
        updateContactSettings,
        reports,
        addPropertyReport,
        resolvePropertyReport,
        propertyVideos,
        loadPropertyVideos,
        addPropertyVideo,
        updatePropertyVideoStatus,
        deletePropertyVideo,
        updatePropertyListingStatus,
        assignPropertyToAgent,
        agencyCollaborators,
        inviteAgencyCollaborator,
        updateAgencyCollaborator,
        deleteAgencyCollaborator,
        agencyTransactions,
        createAgencyTransaction,
      }}
    >
      <div dir={languages.find((l) => l.code === language)?.dir || 'ltr'}>
        {children}
      </div>

      {confirmState && (
        <div className="fixed inset-0 z-[99999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl relative">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-xl font-bold text-white">
                {confirmState.title || 'Confirmation de suppression'}
              </h3>
              <p className="text-slate-300 text-sm leading-relaxed">
                {confirmState.message}
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setConfirmState(null)}
                className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-sm transition-all"
              >
                {confirmState.cancelText || 'Annuler'}
              </button>
              <button
                type="button"
                onClick={() => {
                  try {
                    confirmState.onConfirm();
                  } catch (e) {
                    console.error('Error executing confirm action:', e);
                  } finally {
                    setConfirmState(null);
                  }
                }}
                className="flex-1 py-3 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-sm shadow-lg shadow-rose-500/20 transition-all flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                {confirmState.confirmText || 'Supprimer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
