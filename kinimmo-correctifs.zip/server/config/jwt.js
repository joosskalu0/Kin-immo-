require('dotenv').config();

/**
 * Source unique du secret JWT (auparavant 3 valeurs par défaut différentes
 * dans middleware/auth.js, container.js et JwtTokenService.js).
 */
const FALLBACK_SECRET = 'kinimmo_jwt_secret_default_key_2026';

const JWT_SECRET = process.env.JWT_SECRET || FALLBACK_SECRET;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '15d';

if (!process.env.JWT_SECRET) {
  console.error(
    '[SÉCURITÉ] JWT_SECRET est absent du fichier .env : un secret PUBLIC par défaut est utilisé. ' +
    'N\'importe qui peut alors fabriquer de faux jetons. Définissez JWT_SECRET (chaîne aléatoire de 32+ caractères).'
  );
} else if (process.env.JWT_SECRET.includes('kinimmo_super_secret_jwt_key_2026')) {
  console.error('[SÉCURITÉ] JWT_SECRET est identique à la valeur d\'exemple de .env.example : remplacez-la.');
}

module.exports = { JWT_SECRET, JWT_EXPIRES_IN };
